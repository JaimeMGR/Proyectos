/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.ejemplo_junit3;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Profesor
 */
public class OperacionesTest {   
    public OperacionesTest() {
    }

    /**
     * Test of sumaArray method, of class Operaciones.
     */
    @Test
    public void testSumaArray() {
        System.out.println("sumaArray");
        //Given
        Operaciones instance = new Operaciones();
        //When
        int[] array = {2, 5, 7, 4, 1};
        int expResult = 19;
        int result = instance.sumaArray(array);
        //Then
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMayorElementoArray() {
        System.out.println("mayorElementoArray");
        //Given
        Operaciones instance = new Operaciones();
        //When
        int[] array = {2, 5, 7, 4, 1};
        int expResult = 7;
        int result = instance.mayorElementoArray(array);
        //Then
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMenorElementoArray() {
        System.out.println("menorElementoArray");
        //Given
        Operaciones instance = new Operaciones();
        //When
        int[] array = {2, 5, 7, 4, 1};
        int expResult = 1;
        int result = instance.menorElementoArray(array);
        //Then
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMayorMenorElementoArray() {
        System.out.println("mayorMenorElementoArray");
        //Given
        Operaciones instance = new Operaciones();
        int[] array = {2, 5, 7, 4, 1};
        //When
        int tipo = Operaciones.MAYOR;
        int expResult = 7;
        int result = instance.mayorMenorElementoArray(array, tipo);
        //Then
        assertEquals(expResult, result);
        
        //When
        tipo = Operaciones.MENOR;
        expResult = 1;
        result = instance.mayorMenorElementoArray(array, tipo);
        //Then
        assertEquals(expResult, result);
    }
    
}
