package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TestCalidad extends JFrame {

    private JTextField campoNombre, campoApellidos, campoEmail, campoTelefono;

    private JRadioButton radioHombre, radioMujer;

    private JComboBox<String> comboEstadoCivil;
    private JButton buttonEnviar;

    private JPanel panel1;
    private JLabel labelNombre, labelApellidos, labelEmail, labelTelefono, labelGenero, labelEstadoCivil;


    public TestCalidad() {

        setTitle("Test de Calidad");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear componentes del formulario
        labelNombre = new JLabel("Nombre:");
        labelApellidos = new JLabel("Apellidos:");
        labelEmail = new JLabel("Email:");
        labelTelefono = new JLabel("Teléfono:");
        labelGenero = new JLabel("Genero:");
        labelEstadoCivil = new JLabel("Estado Civil:");

        campoNombre = new JTextField(20);
        campoApellidos = new JTextField(20);
        campoEmail = new JTextField(20);
        campoTelefono = new JTextField(20);
        radioHombre = new JRadioButton("Hombre");
        radioMujer = new JRadioButton("Mujer");

        ButtonGroup grupoGenero = new ButtonGroup();
        grupoGenero.add(radioHombre);
        grupoGenero.add(radioMujer);

        String[] opcionesEstadoCivil = {"Casado", "Soltero", "Viudo"};
        comboEstadoCivil = new JComboBox<>(opcionesEstadoCivil);


        buttonEnviar = new JButton("Enviar");

        // Cambiar la fuente y el color de los componentes
        campoNombre.setFont(new Font("Roboto", Font.ITALIC, 12));
        campoNombre.setForeground(Color.black);
        campoApellidos.setFont(new Font("Roboto", Font.ITALIC, 12));
        campoApellidos.setForeground(Color.black);
        campoEmail.setFont(new Font("Roboto", Font.ITALIC, 12));
        campoEmail.setForeground(Color.black);
        campoTelefono.setFont(new Font("Roboto", Font.ITALIC, 12));
        campoTelefono.setForeground(Color.black);
        buttonEnviar.setFont(new Font("Roboto", Font.ITALIC, 18));
        buttonEnviar.setForeground(Color.black);
        buttonEnviar.setBackground(new Color(50, 120, 220));

        // Establecer márgenes en los campos de texto
        Insets margenes = new Insets(10, 0, 10, 10); // Márgenes superior, izquierdo, inferior, derecho
        campoNombre.setMargin(margenes);
        campoApellidos.setMargin(margenes);
        campoEmail.setMargin(margenes);
        campoTelefono.setMargin(margenes);

        // Establecer margen izquierdo a los labels
        labelNombre.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0)); // Añado margen izquierdo a los labels
        labelApellidos.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        labelEmail.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        labelTelefono.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        labelGenero.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        labelEstadoCivil.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));


        buttonEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String valorNombre = campoNombre.getText();
                String valorApellidos=campoApellidos.getText();
                String valorEmail=campoEmail.getText();
                String valorTelefono=campoTelefono.getText();
                String genero = radioHombre.isSelected() ? "Hombre" : "Mujer";
                String estadoCivil = (String) comboEstadoCivil.getSelectedItem();
//                Resultado.main(new String[]{valorNombre,valorApellidos,valorEmail,valorTelefono, genero, estadoCivil});
                new Resultado(valorNombre, valorApellidos, valorEmail, valorTelefono, genero, estadoCivil);
            }
        });

        // Configurar el diseño de la ventana
        setLayout(new GridLayout(8, 2));

        // Agregar componentes al contenido de la ventana
        add(labelNombre);
        add(campoNombre);
        add(labelApellidos);
        add(campoApellidos);
        add(labelEmail);
        add(campoEmail);
        add(labelTelefono);
        add(campoTelefono);
        add(labelGenero);

        // Crear un nuevo panel para los radioButtons
        JPanel panelGenero = new JPanel(new GridLayout(2, 1)); // 2 filas para las dos opciones
        panelGenero.add(radioHombre);
        panelGenero.add(radioMujer);

        // Agregar el panel al contenido de la ventana
        add(panelGenero);

        add(labelEstadoCivil);
        add(comboEstadoCivil);
        add(new JLabel()); // Espacio en blanco
        add(buttonEnviar);

        // Hacer visible la ventana
        setVisible(true);
    }

    public static void main(String[] args) throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TestCalidad();
            }
        });
    }
}
