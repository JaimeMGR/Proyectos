package org.example;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Resultado extends JFrame {

    private JPanel panel1;
    private JLabel titulo;
    private JLabel nombreLabel;
    private JLabel nombreResultado;
    private JLabel apellidosLabel;
    private JLabel apellidosResultado;
    private JLabel emailLabel;
    private JLabel emailResultado;
    private JLabel telefonoLabel;
    private JLabel telefonoResultado;
    private JLabel generoLabel;
    private JLabel generoResultado;
    private JLabel estadoCivilLabel;
    private JLabel estadoCivilResultado;

    public Resultado(String nombre, String apellidos, String email, String telefono, String genero, String estadoCivil) {
        setTitle("Resultado");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panelResultado = new JPanel(new GridLayout(6, 2, 10, 10));
        panelResultado.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Crear JLabels
        JLabel nombreLabel = new JLabel("Nombre:");
        JLabel apellidosLabel = new JLabel("Apellidos:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel telefonoLabel = new JLabel("Teléfono:");
        JLabel generoLabel = new JLabel("Género:");
        JLabel estadoCivilLabel = new JLabel("Estado Civil:");

        // Crear JLabels para mostrar los datos
        JLabel nombreValorLabel = new JLabel(nombre);
        JLabel apellidosValorLabel = new JLabel(apellidos);
        JLabel emailValorLabel = new JLabel(email);
        JLabel telefonoValorLabel = new JLabel(telefono);
        JLabel generoValorLabel = new JLabel(genero);
        JLabel estadoCivilValorLabel = new JLabel(estadoCivil);

        // Dar estilo a los JLabels
        nombreValorLabel.setFont(new Font("Arial", Font.BOLD, 14));
        apellidosValorLabel.setFont(new Font("Arial", Font.BOLD, 14));
        emailValorLabel.setFont(new Font("Arial", Font.BOLD, 14));
        telefonoValorLabel.setFont(new Font("Arial", Font.BOLD, 14));
        generoValorLabel.setFont(new Font("Arial", Font.BOLD, 14));
        estadoCivilValorLabel.setFont(new Font("Arial", Font.BOLD, 14));

        // Añadir JLabels al panel
        panelResultado.add(nombreLabel);
        panelResultado.add(nombreValorLabel);
        panelResultado.add(apellidosLabel);
        panelResultado.add(apellidosValorLabel);
        panelResultado.add(emailLabel);
        panelResultado.add(emailValorLabel);
        panelResultado.add(telefonoLabel);
        panelResultado.add(telefonoValorLabel);
        panelResultado.add(generoLabel);
        panelResultado.add(generoValorLabel);
        panelResultado.add(estadoCivilLabel);
        panelResultado.add(estadoCivilValorLabel);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelResultado, BorderLayout.CENTER);

        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Resultado("Ejemplo", "ApellidoEjemplo", "ejemplo@email.com", "123456789", "Hombre", "Soltero");
            }
        });
    }
}