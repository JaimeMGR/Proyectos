package org.example.turiticappv2

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.paddingFrom
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.google.relay.compose.BoxScopeInstance.columnWeight
import com.google.relay.compose.BoxScopeInstance.rowWeight
import org.example.turiticappv2.pantallaalhambra.PantallaAlhambra
import org.example.turiticappv2.pantallaprincipal.PantallaPrincipal
import org.example.turiticappv2.pantallacatedral.PantallaCatedral
import org.example.turiticappv2.pantallasanmiguel.PantallaSanMiguel
import org.example.turiticappv2.ui.theme.TuriticAppV2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TuriticAppV2Theme {
                    PantallaPrincipal(
                        button1Text = "Alhambra",
                        button2Text = "Catedral de Granada",
                        button3Text = "San Miguel Alto",
                        button1Tap = { alhambra() },
                        button2Tap = { catedral() },
                        button3Tap = { miguelito() },
                        modifier = Modifier
                            .rowWeight(1.0f)
                            .columnWeight(1.0f)
                    )
            }
        }

    }

    fun miguelito(){
        this.setContent {
            TuriticAppV2Theme {
                PantallaSanMiguel(
                    img = painterResource(R.drawable.pantalla_san_miguel_img),
                    textScreen = "San miguel, el que no es bajo",
                    menuButtonText = "Menu",
                    secondButtonText = "Alhambra",
                    thirdButtonText = "Catedral",
                    menuButtonTapped = {menu()},
                    secondButtonTapped = {alhambra()},
                    thirdButtonTapped = {catedral()},
                    modifier = Modifier
                        .rowWeight(1.0f)
                        .columnWeight(1.0f)
                )
            }
        }
    }

    fun alhambra(){
        this.setContent{
            TuriticAppV2Theme {
                PantallaAlhambra(
                    textScreen = "Esta es la Alhambra de mis amore",
                    imgContent = painterResource(R.drawable.pantalla_alhambra_img),
                    textButton1 = "Menu",
                    textButton2 = "Catedral",
                    textButton3 = "San Miguel Alto",
                    buttonTapped1 = {menu()},
                    buttonTapped2 = { catedral() },
                    buttonTapped3 = { miguelito() },
                    modifier = Modifier
                        .rowWeight(1.0f)
                        .columnWeight(1.0f)
                )
            }
        }
    }

    fun catedral(){
        this.setContent{
            PantallaCatedral(
                screenText = "Una catedra'",
                img = painterResource(R.drawable.pantalla_catedral_img),
                menuButtonText = "Menu",
                secondButtonText = "Alhambra",
                thirdButtonText = "San Miguel Alto",
                menuButtonTapped = {menu()},
                secondButtonTapped = {alhambra()},
                thirdButtonTapped =  {miguelito()},
                modifier = Modifier
                    .rowWeight(1.0f)
                    .columnWeight(1.0f)
            )
        }
    }

    fun menu(){
        this.setContent{
            TuriticAppV2Theme {
                PantallaPrincipal(
                    button1Text = "Alhambra",
                    button2Text = "Catedral de Granada",
                    button3Text = "San Miguel el Alto",
                    button1Tap = { alhambra() },
                    button2Tap = { catedral() },
                    button3Tap = { miguelito() },
                    modifier = Modifier
                        .rowWeight(1.0f)
                        .columnWeight(1.0f)
                )
            }
        }
    }

}
