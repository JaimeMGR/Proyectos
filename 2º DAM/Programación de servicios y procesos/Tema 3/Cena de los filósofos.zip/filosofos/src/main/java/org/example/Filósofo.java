package org.example;

public class Filósofo extends Thread {

    private int id;
    private Tenedor tenedorIzquierdo;
    private Tenedor tenedorDerecho;

    public Filósofo(int id, Tenedor tenedorIzquierdo, Tenedor tenedorDerecho) {
        this.id = id;
        this.tenedorIzquierdo = tenedorIzquierdo;
        this.tenedorDerecho = tenedorDerecho;
    }

    @Override
    public void run() {
        while (true) {
            // Pensar
            pensar();

            // Intentar coger los tenedores
            try {
                tenedorIzquierdo.coger();
                tenedorDerecho.coger();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Comer
            comer();

            // Soltar los tenedores
            tenedorIzquierdo.soltar();
            tenedorDerecho.soltar();
        }
    }

    private void pensar() {
        System.out.println("El filósofo " + id + " está pensando.");
    }

    private void comer() {
        System.out.println("El filósofo " + id + " está comiendo.");
    }
}
