package org.example;

public class Main {

    public static void main(String[] args) {
        // Crear los tenedores
        Tenedor tenedor1 = new Tenedor();
        Tenedor tenedor2 = new Tenedor();
        Tenedor tenedor3 = new Tenedor();
        Tenedor tenedor4 = new Tenedor();
        Tenedor tenedor5 = new Tenedor();

        // Crear los filósofos
        Filósofo filósofo1 = new Filósofo(0, tenedor1, tenedor2);
        Filósofo filósofo2 = new Filósofo(1, tenedor2, tenedor3);
        Filósofo filósofo3 = new Filósofo(2, tenedor3, tenedor4);
        Filósofo filósofo4 = new Filósofo(3, tenedor4, tenedor5);
        Filósofo filósofo5 = new Filósofo(4, tenedor5, tenedor1);

        // Iniciar los hilos de los filósofos
        filósofo1.start();
        filósofo2.start();
        filósofo3.start();
        filósofo4.start();
        filósofo5.start();
    }
}
