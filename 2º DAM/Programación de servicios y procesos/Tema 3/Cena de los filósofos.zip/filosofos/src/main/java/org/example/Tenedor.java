package org.example;

public class Tenedor {

    private boolean ocupado;

    public Tenedor() {
        ocupado = false;
    }

    public synchronized void coger() throws InterruptedException {
        while (ocupado) {
            wait();
        }
        ocupado = true;
    }

    public synchronized void soltar() {
        ocupado = false;
        notifyAll();
    }
}
