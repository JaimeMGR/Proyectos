<footer>
    <div class="info-footer">
        <div class="d-flex">
            <div class="logocontainer" style="text-align:center; padding-top:10px;">
                <img src="../../imagenes/logo.png">
            </div>
            <div class="footermenu" style="padding-left:10%;text-align:left;">
                <h4><strong>ENLACES</strong></h4>
                <ul class="navbar-nav">
                    <li>
                        <a href="../../index.php">
                            <button class="btn text-light" type="button">Inicio</button>
                        </a>
                    </li>
                    <li>
                        <a href="../noticia/noticias.php">
                            <button class="btn text-light" type="button">Noticias</button>
                        </a>
                    </li>
                    <li>
                        <a href="../cita/clases.php">
                            <button class="btn text-light" type="button">Citas</button>
                        </a>
                    </li>
                    <li>
                        <a href="../servicio/servicios.php">
                            <button class="btn text-light" type="button">Servicios</button>
                        </a>
                    </li>
                    <li>
                        <a href="../entrenadores/entrenadores.php">
                            <button class="btn text-light" type="button">Entrenadores</button>
                        </a>
                    </li>
                    <li>
                        <a href="../socios/socios.php">
                            <button class="btn text-light" type="button">Socios</button>
                        </a>
                    </li>
                    <li>
                        <a href="../testimonios/testimonios.php">
                            <button class="btn text-light" type="button">Testimonios</button>
                        </a>
                    </li>
                    <li>
                        <a href="../contacto/contacto.php">
                            <button class="btn text-light" type="button">Contactos</button>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="contacto-footer">
                <h4><strong>CONTACTO</strong></h4>
                <ul class="navbar-nav ms-auto">
                    <li>
                        <h7><strong>Dirección:</strong> Calle Don Óscar 48,<br>Maracena, España</h7>
                    </li>
                    <br>
                    <li>
                        <h7><strong>Teléfono:</strong> +34 000000000</h7>
                    </li>

                    <br>
                </ul>
            </div>
        </div>
    </div>
    <div class="textos-legales">

    </div>
</footer>