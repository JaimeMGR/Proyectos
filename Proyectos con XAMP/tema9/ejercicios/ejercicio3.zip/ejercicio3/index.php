<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "centro";  // Nombre de la base de datos proporcionada

// Crear conexión
$conexion = new mysqli($servername, $username, $password, $dbname);
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Consulta SQL para obtener los alumnos ordenados por edad
$consulta = "SELECT `nombre_completo`,`nombre_asignatura`, `anio`, `nota` FROM `centro`.`matriculas`,`alumnos`,`asignaturas` ";

$resultado=$conexion->query($consulta);

// Crear la tabla si hay resultados
if ($resultado->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ALUMNO</th>
                <th>ASIGNATURA</th>
                <th>AÑO</th>
                <th>NOTA</th>
            </tr>";

    // Mostrar cada fila de los resultados
    while ($datos = $resultado->fetch_assoc()) {
        echo "<tr>
                <td>" . $datos["nombre_completo"] . "</td>
                <td>" . $datos["nombre_asignatura"] . "</td>
                <td>" . $datos["anio"] . "</td>
                <td>" . $datos["nota"] . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No se encontraron alumnos.";
}

// Cerrar la conexión
$conexion->close();
?>


</body>
</html>