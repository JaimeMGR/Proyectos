<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "centro";  // Nombre de la base de datos proporcionada

// Crear conexión
$conexion = new mysqli($servername, $username, $password, $dbname);
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_asignatura = trim($_POST['nombre_asignatura']);
    $creditos = trim($_POST['creditos']);

    if($nombre_asignatura == "" || $creditos == ""){
        echo "Todos los campos son obligatorios";
        exit;
    }else{

    // Consulta SQL para obtener los alumnos ordenados por edad
    $consulta = "INSERT INTO `asignaturas` (`id_asignatura`, `nombre_asignatura`, `creditos`) VALUES (NULL, '$nombre_asignatura', '$creditos')";
    $resultado=$conexion->query($consulta);

    echo "Asignatura creada correctamente";

    // Cerrar la conexión
    $conexion->close();
    }
}else{
    $conexion->close();

}
?>
</body>
</html>