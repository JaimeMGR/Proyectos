<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Informacioón de alumno</h1>
    <form action="DatosAlumno.php" method="POST">
    <label for="nombre_completo">Nombre completo:</label>
    <input type="text" id="nombre_completo" name="nombre_completo" required><br><br>
    <label for="DNI">DNI:</label>
    <input type="text" id="DNI" name="DNI" required><br><br>
    <label for="Nota">Nota:</label>
    <select name="nota" id="lang" required>
        <option value="0">0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
      </select><br><br>
      <label for="edad">Edad:</label>
    <input type="number" id="edad" name="edad" required><br><br>
    <input type="number" id="anio" name="anio" hidden="true" value="2024" required><br>
    <input type="submit" value="Enviar">
    </form>
</body>
</html>

<!-- INSERT INTO Matriculas (dni_alumno, id_asignatura, anio, nota) VALUES
('55555555Z', 1, 2020, 8)

INSERT INTO Alumnos (dni, nombre_completo, edad) VALUES
('55555555Z', 'Ramón Torres', 19) -->