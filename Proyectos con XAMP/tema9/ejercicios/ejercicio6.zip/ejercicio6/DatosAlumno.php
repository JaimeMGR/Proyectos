<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    // Datos de conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "centro";  // Nombre de la base de datos proporcionada
    
    // Crear conexión
    $conexion = new mysqli($servername, $username, $password, $dbname);
    $conexion->set_charset("utf8");
    
    //Nombre enviado por el formulario
        $nombre_completo = trim($_POST['nombre_completo']);
        $DNI = trim($_POST['DNI']);
        $Edad = trim($_POST['edad']);
        $Año = trim($_POST['anio']);
        $Nota = trim($_POST['nota']);
    
    if ($conexion->connect_error) {
        die("Conexión fallida: " . $conexion->connect_error);
    }


    // Consulta SQL para obtener los datos del alumno segun el nombre
    $Alumnos = "INSERT INTO Alumnos (dni, nombre_completo, edad) VALUES
                ('$DNI', '$nombre_completo', $Edad);"; 
    
    $Matriculas="INSERT INTO Matriculas (dni_alumno, id_asignatura, anio, nota) VALUES
                ('$DNI', 1, 2024, $Nota),
                ('$DNI', 2, 2024, $Nota),
                ('$DNI', 3, 2024, $Nota),
                ('$DNI', 4, 2024, $Nota),
                ('$DNI', 5, 2024, $Nota),
                ('$DNI', 6, 2024, $Nota),
                ('$DNI', 7, 2024, $Nota),
                ('$DNI', 8, 2024, $Nota);";


;
    
    $resultado=$conexion->query($Alumnos);
    $resultado=$conexion->query($Matriculas);

        echo "Alumno registrado correctamente";
        // Cerrar la conexión
        $conexion->close();
    
    ?>
    
    
    </body>
    </html>